#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Code isolates the program functionality from everything
// Finds the lenth of the ./ input
void programNameFunction(char* argv[]){
    // Produces appropriate text
    printf("Proper usage: ");

    // Finds the input size
    int programNameFinder = 0;
    while(argv[0][programNameFinder] != '\0'){
        programNameFinder += 1;
    }

    // This gives the array it's size
    int programArrayName[programNameFinder];

    //While argv element is not nothing
    int i = 2;
    while(argv[0][i] != '\0'){
        programArrayName[i] = argv[0][i];
        i += 1;
    }

    // Iterator J prints out the array name
    // showing the program name onto output
    int j = 2;
    while(j < programNameFinder){
        printf("%c", programArrayName[j]);
        j += 1;
    }

    // Closes text and ends function
    printf(" <strictly positive integer>\n");
    exit(1);
}

//Program Checks for any alphabetical inputs in input
void userNumberCheck(char* userNumberFloatCheck, int userNumber){

    // By setting letterCheck as 0, it will go through the length of the userinput
    // checking each input until it finds a character that isn't within the ASCII
    // range of normal numbers
    int letterCheck = 0;
    while(letterCheck <= strlen(userNumberFloatCheck)-1){
        if (!((userNumberFloatCheck[letterCheck] > 47) && (userNumberFloatCheck[letterCheck] < 58))) {
            // If a non-number character is found, end the program.
            printf("The argument is not a strictly positive integer.\n");
            exit(1);
        }
        letterCheck += 1;
    }

    // Check to see if its above 0, has no additional numbers, and isn't alphabetical
    if(userNumber <= 0){
        printf("The argument is not a strictly positive integer.\n");
        exit(1); 
    }

    // Checks to see if the userNumber is a 1 to avoid performing
    // calculations and to give a straight answer
    if(userNumber == 1){
        printf("The first prime number is: 2.\n");
        exit(1);
    }
}

int main(int argc, char *argv[]){
    // Checks if there are any valid inputs first
    if(argc == 1){
       programNameFunction(argv);
    }

    // Assigns values to userNumber, as well
    // as it's float variant
    int userNumber = atoi(argv[1]);
    char* userNumberFloatCheck = argv[1];

    // Checks for any alphabetical characters in number input
    // as well as some userNumber exceptions
    userNumberCheck(userNumberFloatCheck, userNumber);

    // Array "primeNumberList" that will store prime numbers
    int primeNumberList[userNumber];

    // Integers that will help act as iterators for the further calculations
    int isPrime = 0, listIterator = 0, count = 2;

    //Calculations to see if number is prime or not
    while(listIterator <= userNumber){
        // While the listIterator is less than the userNumber
        // see if count mod prime is equal to zero, and
        // increase isPrime by one if it is
        for(isPrime = 2; isPrime < count; isPrime++){
            if(count % isPrime == 0){
                isPrime = count + 1;
            }
        }
        // If isPrime is equal to count, meaning it's
        // prime, include it onto the primeNumberList
        if(isPrime == count){
            primeNumberList[listIterator] = count;
            listIterator += 1;
            }
        count += 1;
    }
    
    // Extra-Credit step to determine what number will be printed
    if(userNumber <= 20){
        char* digits[19] = {"two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven",
        "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"};
        printf("The first %s prime number are:", digits[userNumber - 2]);
    }
    else{
        // Prints all of the prime numbers, with a period on the
        // end as well if necessary
        printf("The first %d prime numbers are:", userNumber);
    }
    // Prints all prime numbers, as well as the 
    // last number with a period at the end.
    for(int i = 0; i < userNumber; i++){
        if((i+1) == userNumber){
                printf(" %d.\n", primeNumberList[i]);
                return 0;
        }
        printf(" %d,", primeNumberList[i]);
    }
}