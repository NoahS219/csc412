#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Code isolates the program functionality from everything
// Finds the lenth of the ./ input
void programNameFunction(char* argv[]){
    // Produces appropriate text
    printf("Proper usage: ");

    // Finds the input size
    int programNameFinder = 0;
    while(argv[0][programNameFinder] != '\0'){
        programNameFinder += 1;
    }

    // This gives the array it's size
    int programArrayName[programNameFinder];

    // While argv element is not nothing, iterate 
    // through and add to programArrayName
    int i = 2;
    while(argv[0][i] != '\0'){
        programArrayName[i] = argv[0][i];
        i += 1;
    }

    // Iterator J prints out the array name
    // showing the program name onto output
    int j = 2;
    while(j < programNameFinder){
        printf("%c", programArrayName[j]);
        j += 1;
    }

    // Closes text and ends function
    printf(" <strictly positive integer>\n");
    exit(1);
}

// Void errorHanding will handle all of the test cases that are specific
// to any issues that could arise with the user input
void errorHandling(int userNumber, int userNumber2, char* userNumberFloatCheck, char* userNumberFloatCheck2, int argc, char* argv[]){
    
    // Check to see if userNumber is less than/equal to zero
    if(userNumber <= 0){
       printf("The first argument is not a strictly positive integer.\n");
       exit(1);
    }
    
    // Check to see if userNumber2 is less than/equal to zero
    if(userNumber2 <= 0){
       printf("The second argument is not a strictly positive integer.\n");
       exit(1);
    }
    
    // Checks the first input for any letters in the number input
    // for no additional characters, like float numbers or random characters
    int letterCheck = 0;
    while(letterCheck <= strlen(userNumberFloatCheck)-1){
        if (!((userNumberFloatCheck[letterCheck] > 47) && (userNumberFloatCheck[letterCheck] < 58))) {
            printf("The argument is not a strictly positive integer.\n");
            exit(1);
        }
        letterCheck += 1;
    }
    letterCheck = 0;

    // Checks the second input for any letters in the number input
    // for no additional characters, like float numbers or random characters
    while(letterCheck <= strlen(userNumberFloatCheck2)-1){
        if (!((userNumberFloatCheck2[letterCheck] > 47) && (userNumberFloatCheck2[letterCheck] < 58))) {
            printf("The argument is not a strictly positive integer.\n");
            exit(1);
        }
        letterCheck += 1;
    }
}

// primeFinder function will iterate through the given numbers, and will
// only print out the numbers between the specificed input
int primeFinder(int userNumber, int userNumber2, int printingCheck, int finalVisitCounter){
    int visitCounter = 0;
    // Calculations that perform if the given number is prime or
    // not, based on the values between userNumber 1 and 2
    while(userNumber <= userNumber2)  {   
        int counter = 2, isPrime = 1;
        // Counter and isPrime are set to 2 and 1
        // respectively, that way once the next while
        // loop is finished iterating through each element
        // to determine if it's prime or not
        while(counter <= userNumber/2 || userNumber == 1){  
            if(userNumber % counter == 0 || userNumber == 1)  {  
                isPrime = 0; // Set isPrime to 0 if it isn't prime
                break;  
            }  
            counter++;  
        }

        // If isPrime equals 1 (meaning it is prime) and
        // if the userNumber does not equal zero, then go
        // about printing the given prime number
        if(isPrime == 1 && userNumber != 0){
            visitCounter += 1;
            if(printingCheck == 1 && finalVisitCounter != 1 && userNumber != 0){
                // If visitCounter equals the finalized count
                // of each prime number, include a period at the
                // end of the statement to conclude it
                if(visitCounter == finalVisitCounter){
                printf("%d. \n", userNumber);
                exit(1);
            }
            printf("%d, ", userNumber);
            }
            // If visitCounter equals 1
            // and userNumber doesn equal 0
            // conclude this one prime number statement.
            else if(printingCheck == 1 && visitCounter == 1 && userNumber != 0){
                printf("%d. \n", userNumber);
            }
            }
            userNumber++;  
        }
    // Will return visitCounter, which will
    // help respond back how many prime numbers
    // are in a loop, as well as for special test
    // cases
    return visitCounter;
}


// Main function that executes the rest of the program
int main(int argc, char *argv[])  {  
    if(argc == 1){
        programNameFunction(argv);
    }
    
    // Takes the first and second input to
    // have the prime numbers between them
    // printed
    int userNumber = atoi(argv[1]);
    int userNumber2 = atoi(argv[2]);
    int originalUserNumber = atoi(argv[1]);

    // Takes the string values of the user
    // input so that they can be tested for
    // any special characters as well
    char* userNumberFloatCheck = argv[1];
    char* userNumberFloatCheck2 = argv[2];

    // Error Handling function will check for given user inputs to
    // see if they are viable to use in later functionality or not
    errorHandling(userNumber, userNumber2, userNumberFloatCheck, userNumberFloatCheck2, argc, argv);

    // printingCheck && finalVisitCounter both act as variables
    // which select the proper printing function, based on the
    // values of the two user input. printingCheck will allow
    // for the actual printing of values, which occurs once
    // the visit counters have been set.
    int printingCheck = 0;
    int finalVisitCounter = 0;
    int visitCounter = primeFinder(userNumber, userNumber2, printingCheck, finalVisitCounter);
    finalVisitCounter = primeFinder(userNumber, userNumber2, printingCheck, finalVisitCounter);

    // Set printingCheck to 1 so that a statement within the primeChecker
    // can print out values
    printingCheck = 1;

    // If no spots are visited, print that there are no prime numbers
    if (visitCounter == 0) {
        printf("There is no prime number between %d and %d.\n", originalUserNumber, userNumber2);
    }
    // If there is only one prime number, print that there is
    else if (visitCounter == 1) {
        printf("There is only one prime number between %d and %d: ", originalUserNumber, userNumber2);
        visitCounter = primeFinder(userNumber, userNumber2, printingCheck, finalVisitCounter);
    }
    // Otherwise, print out the prime numbers
    else{
        printf("There is %d prime numbers between %d and %d: ", visitCounter, originalUserNumber, userNumber2);
        visitCounter = primeFinder(userNumber, userNumber2, printingCheck,finalVisitCounter);
    }
} 