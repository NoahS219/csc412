#!/bin/bash
gcc -Wall Programs/prog01v1.c -o $1v1
gcc -Wall Programs/prog01v2.c -o $1v2