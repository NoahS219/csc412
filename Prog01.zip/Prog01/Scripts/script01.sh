#!/bin/bash
#runs the build script
Scripts/build.sh $1

# Number of args
arguementCount=$#

# Set the biggest num to the second input
biggestNum=$2

# Sets arguementArray to be all elements
arguementArray=( "$@" )

# Empty array that will store no duplicate numbers
declare -a noDuplicateArray

# Loop through array holding all numbers
for ifDuplicateCheck in "${arguementArray[@]:1:$arguementCount}" 
do

  # Check if the ifDuplicate is in noDuplicate
  # make found zero for if it does find something,
  # then break the loop
    found=0
    for noDuplicateCheck in "${noDuplicateArray[@]}"
    do

        # If ifDuplicate equals noDuplicateCheck, then equal
        # found to be one and break the loop
        if [[ "$ifDuplicateCheck" == "$noDuplicateCheck" ]]; then
            found=1
            break
        fi
    done
  
# If found equals zero, meaning theres no duplicates in
# noDuplicateArray, then add it to the noDuplicateArray
if [[ $found -eq 0 ]]; then
    noDuplicateArray+=( "$ifDuplicateCheck" )
    fi
done

# Helps find the biggest number for version 1 to print
for number in ${noDuplicateArray[@]}
do
    if [ $biggestNum -lt $number ]; then
        biggestNum=$number
    fi
done

# Runs the first function with the biggestNumber
./$1v1 $biggestNum

count=1
# Nested for loop to check the prime numbers between values
for i in ${noDuplicateArray[@]}
do 
    for j in ${noDuplicateArray[@]:count}
    do
        # Ensures numbers are of the right size, and increments accordingly
        if [ $i -lt $j ]; then
            ./$1v2 $i $j
        else
        ./$1v2 $j $i
        fi
    done
    # Increments count by one
    count=$[count+1]
done