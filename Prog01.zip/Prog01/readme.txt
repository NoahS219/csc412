Noah Santagata || Prof. Herve || CSC 412 || February 3rd, 2023

**EXTRA CREDIT**

In this assignment, there were extra credit steps that I have
successfully completed, resulting in a more thorough code.

VERSION 1

*2.3.3*
My code is able to successfully produce the name of the given number
when asked to produce the first few prime numbers, up to 20. This was
achieved by creating a list with the names of the given numbers, and by
calling the list of the given number(subtracting by two due to lists
starting at 0 and me not having one in this list) was I able to successfully
print out the given number name.

*2.3.4*
My code is able to successfully produce the filename of the given code, 
removing the filename up to it. It performs this by finding the size of the
output filename, and printing it back out but excluding the inital "./" at
the beginning.

VERSION 2

*2.4.3*
My code is able to print out the amount of prime numbers are between two
numbers. It achieves this by counting how many times a prime number is found
so in my final print statement where I produce the outcome, I just have to 
also print out the variable "visitCounter" which keeps track of it for me.

*2.4.3*
My code is able to produce the first prime number if only given one input,
check if there is only one prime number present, and if no prime numbers
exist between two given inputs. It achieves this by keeping track of how many
times the prime finding function performs certain tasks through variables, and
if certian variables meet certain criteria within the printing section, it will
produce a statement that is in-line with the condition.

VERSION 3

*3.5*
My code is able to produce a list with no duplicates. It's able to achieve this
by having a for-loop iterate through my main array. It compares different numbers
against one another using another for-loop (essentially we have a nested for loop here), 
and if one does exist, it will skip over the section that would put the given number into 
another array, and keep searching for more numbers. It essentially puts non duplicate numbers 
into an array, and the rest of my scripting runs off that.