#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <dirent.h>
#include <string.h>
#include "rasterImage.h"
#include "imageIO_TGA.h"
#include "operations.h"

int main(int argc, const char* argv[]) {
    // Checks initially to see if enough
    // arguments are given
    if (argc < 3 || argc > 3){
        printf("Not the proper amount of inputs\n");
        exit(1);
    }

    // Has file1 and file2 read in as raster
    // images from user input
    RasterImage file1 = readTGA(argv[1]);
    RasterImage file2 = readTGA(argv[2]);

    // Compares file1 and file 2 against compared found in operations
    int compared = compare(&file1, &file2);

    // Checks to see what compared returned
    if (compared == 1){
        //printf("Successful Comparison\n");
        return 1;
    }
    if (compared == 0){
        //printf("Un-successful Comparison, images dont match\n");
        return 0;
    }

    // As the instructions don't state how to include/incorporate
    // some of extra-credit into our code, I have commented them out
    // with a quick uncomment of each function enabling it to work 
    // accordingly. To note, the original "compare" function above
    // might need to be commented out in order for these to work

    // ** EXTRA CREDIT **
    // comparedFz finds if the percentage between 
    // the two images is less than 5 percent

    // int comparedFz = compareFz(&file1, &file2);

    // if (comparedFz == 1){
    //     printf("Images have a difference less than 5 percent.\n");
    //     return 1;
    // }
    // if (comparedFz == 0){
    //     printf("Images have a difference more than 5 percent.\n");
    //     return 0;
    // }


    // ** EXTRA CREDIT **
    // comparedSm finds if the image has been 
    // flipped vertically or horizontally

    // int comparedSm = compareSm(&file1, &file2);
    // if(comparedSm == 0){
    //     printf("The images were not the same dimension.\n");
    // }
    // if(comparedSm == 1){
    //     printf("The image is rotated Horizontally.\n");
    // }
    // if(comparedSm == 2){
    //     printf("The image is rotated Vertically.\n");
    // }
    // if(comparedSm == 3){
    //     printf("The image is rotated neither Vertically or Horizontally.\n");
    // }
    // if(comparedSm == 4){
    //     printf("The images are the same.\n");
    // }
    // return 0;
}