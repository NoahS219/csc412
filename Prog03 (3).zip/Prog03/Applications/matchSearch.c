#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>
#include "rasterImage.h"
#include "imageIO_TGA.h"
#include "operations.h"

int main(int argc, char* argv[]) {
    int foundCounter = 0;

    // Checks initially to see if enough
    // arguments are given
    if (argc < 4 || argc > 4){
        printf("Not the proper amount of inputs\n");
        exit(1);
    }
    // Call matchSearch function
    matchSearch(foundCounter, argv);
}
    