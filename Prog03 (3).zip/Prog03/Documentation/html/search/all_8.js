var searchData=
[
  ['operations_2eh_13',['operations.h',['../operations_8h.html',1,'']]]
];
