var searchData=
[
  ['gray_5fraster_47',['GRAY_RASTER',['../raster_image_8h.html#a3154c405c975616503bac23f51b78fc0a1bf07d3a75c4324ba940a18663b4f5e9',1,'rasterImage.h']]]
];
