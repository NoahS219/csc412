var searchData=
[
  ['operations_2eh_29',['operations.h',['../operations_8h.html',1,'']]]
];
