var searchData=
[
  ['matchsearch_34',['matchSearch',['../operations_8h.html#a9bf88039d87c968aced3e686f6bb3acd',1,'operations.h']]]
];
