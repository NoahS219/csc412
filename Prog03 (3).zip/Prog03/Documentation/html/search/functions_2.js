var searchData=
[
  ['newimage_35',['newImage',['../raster_image_8h.html#a729402985cbea7207fa8b3c8bfd61dc1',1,'rasterImage.h']]]
];
