var searchData=
[
  ['writetga_37',['writeTGA',['../image_i_o___t_g_a_8h.html#a3173b29daaab5b6fc72154e2717fa13f',1,'imageIO_TGA.h']]]
];
