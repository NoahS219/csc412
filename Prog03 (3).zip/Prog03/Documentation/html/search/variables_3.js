var searchData=
[
  ['type_42',['type',['../struct_raster_image.html#a4479a994a2f19c14d9c68a19c9d8061c',1,'RasterImage']]]
];
