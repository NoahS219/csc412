#include "imageIO_TGA.h"
#include "rasterImage.h"

/** Function "compare" is instantiated by an 'int' that is responsible for comparing
 *  two images against one another. Based on the user's discretion, it can compare
 *  similar images, if the image is horizontal/vertical, or if the percentage difference
 *  is less than five. Works in conjuction with matchSearch to pefrom it's calculations.
 * 
 * @param file1 file1 is used in order to grab the image path declared
 *              from the input line, and be used in later calculations
 * 
 * @param file2 file2 is used in order to grab the image path declared
 *              from the input line, and be used in later calculations
 *              typically based around file1.
 * 
 * @return      will return 1 if there was a succcessful comparison
 *              or will return 0 if there wasn't a successful comparison
 */ 
int compare(RasterImage* file1, RasterImage* file2);

/** Function "matchSearch" is instantiated by an 'int' that is responsible for comparing
 *  two images against one another, to see if they're a match or not.
 * 
 * @param file1 file1 is used in order to grab the image path declared
 *              from the input line, and be used in later calculations
 * 
 * @param file2 file2 is used in order to grab the image path declared
 *              from the input line, and be used in later calculations
 *              typically based around file1.
 * 
 * @return      will return 0 once it's completed.
 */ 
int matchSearch(int foundCounter, char* argv[]);

/** Function "compareFz" is instantiated by an 'int' that is responsible for comparing
 *  two images against one another, but finds the difference between the two. Based on if
 *  the difference is less than or equal to 5 percent, will it return different outcomes.
 * 
 * @param file1 file1 is used in order to grab the image path declared
 *              from the input line, and be used in later calculations
 * 
 * @param file2 file2 is used in order to grab the image path declared
 *              from the input line, and be used in later calculations
 *              typically based around file1.
 * 
 * @return      will return 1 if the file was less than or equal to 5
 *              percent of the other one, 0 if not
 */ 
int compareFz(RasterImage* file1, RasterImage* file2);

/** Function "compareSm" is instantiated by an 'int' that is responsible for comparing
 *  two images against one another, but finds to see if the second image is flipped
 *  horizontally or vertically compared to the first image by some set nested for
 *  loops that iterate accordingly
 * 
 * @param file1 file1 is used in order to grab the image path declared
 *              from the input line, and be used in later calculations
 * 
 * @param file2 file2 is used in order to grab the image path declared
 *              from the input line, and be used in later calculations
 *              typically based around file1.
 * 
 * @return      will return 1 if the file was a horizontal flip
 *              will return 2 if the file was a vertical flip
 *              will return 3 if the file was neither a horizontal
 *              or a vertical flip
 */ 
int compareSm(RasterImage* file1, RasterImage* file2);

