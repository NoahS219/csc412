#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include "rasterImage.h"
#include "imageIO_TGA.h"

// The basic "bare-bones" compare function that determines if the two images
// are the same exact pixels. It does this by comparing each pixel value of
// image one to image two
int compare(RasterImage* file1, RasterImage* file2){

    // Ensures they are the proper dimensions before further calculations
    if (file1->width != file2->width || file1->height != file2->height){
        return 0;
    }

    // Compares pixels against one another
    int* raster = (int*)(file1->raster);
    int* raster2 = (int*)(file2->raster);
    for(unsigned int i=0; i<file1->height; i++){
        for (unsigned int j=0; j<file1->width; j++){
            unsigned char* rgba = (unsigned char*) (raster + i*file1->width + j);
            unsigned char* rgba2 = (unsigned char*) (raster2 + i*file2->width + j);
            if (rgba[0] != rgba2[0] || rgba[1] != rgba2[1] || rgba[2] != rgba2[2]){
                return 0;
            }
        }
    }
    return 1;	
}

// The "Fuzzy Compare" function that sees if the two images
// are lower than 5 percent or not. It calculates this by
// increasing a counter whenever the pixels match, and then
// compares that percentage by 5, against 5 percent of the
// original image
int compareFz(RasterImage* file1, RasterImage* file2){
    int counter = 0;
    // Compares pixels against one another
    int* raster = (int*)(file1->raster);
    int* raster2 = (int*)(file2->raster);
    for(unsigned int i=0; i<file1->height; i++){
        for (unsigned int j=0; j<file1->width; j++){
            unsigned char* rgba = (unsigned char*) (raster + i*file1->width + j);
            unsigned char* rgba2 = (unsigned char*) (raster2 + i*file2->width + j);
            if (rgba[0] != rgba2[0] || rgba[1] != rgba2[1] || rgba[2] != rgba2[2]){
                continue;
            }
            else{
                counter += 1;
            }
        }
    }

    // If the second image's percentage pixel count is less than/equal to the original
    // images pixel count, then return 1 since image2's pixel cound is less than 5 percent
    // from the original
    if ( (((counter) * 5) * .01) <= (((file1->width * file1->height) * 5) * .01) ){
        return 1;
    }
    else{
        return 0;
    }
}

// The "Smart Compare" function that determines if the image has
// been rotated vertically or horizontally. It does this by rotating
// the first image itself, and sees if it matches the second images
// by any chance.
int compareSm(RasterImage* file1, RasterImage* file2){
    // Initalizes the rasters
    int* raster = (int*)(file1->raster);
    int* raster2 = (int*)(file2->raster);
    
    // Ensures they are the proper dimensions before further calculations
    if (file1->width != file2->width || file1->height != file2->height){
        return 0;
    }

    // The nested for-loop below checks if the image has been
    // rotated horizontally or not
    int horizontalCheck = 0;
    // Compares pixels against one another
    for (unsigned int i = 0; i < file1->height; i++){
        for (unsigned int j = 0; j < file1->width; j++){
            unsigned char* rgba = (unsigned char*) (raster + i*file1->width + j);
            unsigned char* rgba2 = (unsigned char*) (raster2 + i*file2->width + (file1->width-1-j));
            if (rgba[0] == rgba2[0] && rgba[1] == rgba2[1] && rgba[2] == rgba2[2]){
                continue;
            }
            else{
                horizontalCheck += 1;
            }
        }
    }

    // The nested for-loop below checks if the image has been
    // rotated vertically or not
    int verticalCheck = 0;
    // Compares pixels against one another
    for (unsigned int i = 0; i < file1->height; i++){
        for (unsigned int j = 0; j < file1->width; j++){
            unsigned char* rgba1 = (unsigned char*) (raster + i*file1->width + j);
            unsigned char* rgba2 = (unsigned char*) (raster2 + (file1->height-1-i)*file2->width + j);
            if (rgba1[0] == rgba2[0] && rgba1[1] == rgba2[1] && rgba1[2] == rgba2[2]){
                continue;
            }
            else{
                verticalCheck += 1;
            }
        }
    }

    // Based on the checks before, will return
    // an appropritate value
    if(horizontalCheck == 0){
        return 1;
    }
    if(verticalCheck == 0){
        return 2;
    }
    if(verticalCheck == 1 && horizontalCheck == 1){
        return 3;
    }
    return 4;
}



// int Match search will compare both images against one another
// utilizing the fork() and execvp() commands in order to check
// against each and every image, as well as to operate within 
// ./compare as well
int matchSearch(int foundCounter, char* argv[]){
    
    // Gets the inputs given from terminal
    char* inputImagePath = argv[1];
    char* searchFolderPath = argv[2];
    char* outputFolderPath = argv[3];

    // If the end of searchFolderPath doesn't equal
    // a '/', then free up 2 bits of memory at the
    // end for '/' as well as the null terminator
    // update searchFolderPath with the newly made string
    int searchLength = strlen(searchFolderPath);
    if (searchFolderPath[searchLength-1] != '/') {
        char* searchFolderUpdater = (char*) malloc(searchLength + 2);
        strcpy(searchFolderUpdater, searchFolderPath);
        searchFolderUpdater[searchLength] = '/';
        searchFolderUpdater[searchLength + 1] = '\0';
        searchFolderPath = searchFolderUpdater; 
    }

    // This code is responsible for getting
    // the name of the file path by itself
    char* txtFileName = strrchr(inputImagePath, '/');
    txtFileName = txtFileName + 1;

    // Counter that increments until '.' is met
    // in the file name, counting how much needs
    // to be the length of txtFileNameArray
    int fileNameCounter = 0;
    for(int i = 0; i < strlen(txtFileName); i++){
        if(txtFileName[i] == '.'){
            break;
        }
        fileNameCounter += 1;
    }
    // Creates txtFileNameArray
    char txtFileNameArray[fileNameCounter+1];

    // Increments letters into txtFileNameArray
    for(int i = 0; i < fileNameCounter; i++){
        txtFileNameArray[i] = txtFileName[i];
    }
    // Creates null terminator at the end, and
    // appends .txt at the end
    txtFileNameArray[fileNameCounter] = '\0';
    char txt[] = ".txt";
    strcat(txtFileNameArray, txt);

    // Helps opens the file in the proper directory
    char outputFilePath[400];
    sprintf(outputFilePath, "%s/%s", outputFolderPath, txtFileNameArray);

    // Opens the file
    FILE* outputFile = fopen(outputFilePath, "w");

    // Write user input information to the file
    fprintf(outputFile, "%s\n", inputImagePath);
    fprintf(outputFile, "%s\n", searchFolderPath);

    // Creates the folder directory, dirent struct
    // and opens the searchFolderPath as a directory
    DIR* directory = opendir(searchFolderPath);
    struct dirent* entry;
	directory = opendir(searchFolderPath);

    // While the given entry within the directory does
    // not equal null, operate the code below
    char* matches[400];
    while ((entry = readdir(directory)) != NULL) {
        // View the current directory item
        char* name = entry->d_name;
        char* comparePath = malloc(strlen(searchFolderPath) + strlen(entry->d_name));
        sprintf(comparePath, "%s%s",searchFolderPath, entry->d_name);

        // If name equals a period
        // then continue
        if (name[0] == '.') {
			continue;
        }

        // ID helps create a child process
        int id = fork();

        // If the child process, use execvp to compare information
        // within compare, using the array execInformation
        if (id == 0) {
            char *execInformation[] = {"./compare", inputImagePath, comparePath, NULL};
            execvp("./compare", execInformation);
            // The code after execvp will only be executed if execvp fails
            printf("The execvp failed.\n");
            exit(1);
        } 

        // If ID is greater than zero, code will check if the
        // child process was terminated, and to see if the returning
        // status was valid, if so then append the entry to matches.
        else if (id > 0) {
            int status;
            waitpid(id, &status, 0);
            if (WIFEXITED(status) && WEXITSTATUS(status) == 1) {
                matches[foundCounter] = strdup(entry->d_name);
                foundCounter++;
            }
        } 

        else {
            // This will print if there was a forking error
            printf("The fork failed.\n");
            exit(1);
        }
        // Free memory for comparePath
        free(comparePath);
    }

    // Write the number of matches found out to the file
    fprintf(outputFile, "%d ", foundCounter);

    // Print the list of matching filenames to the file
    for (int i = 0; i < foundCounter; i++) {
        fprintf(outputFile, "%s ", matches[i]);
    }

    // Close the output file
    fclose(outputFile);
	closedir(directory);
    return 0;
}