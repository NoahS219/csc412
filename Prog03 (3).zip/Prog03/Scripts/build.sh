#!/bin/bash
gcc -Wall -I ImageLibrary/include/ ImageLibrary/src/*.c Applications/compare.c -o compare
gcc -Wall -I ImageLibrary/include/ ImageLibrary/src/*.c Applications/matchSearch.c -o search