#!/bin/bash
#runs the build script
Scripts/build.sh
imageInput=$1
searchFolder=$2
outputPath=$3

# Checks the amount of arguments
if [ $# -ne 3 ]; then
  echo "Incorrect amount of inputs."
  exit 1
fi

# Makes the output directory
mkdir "${outputPath}"

# For loop that goes through file and prints each iteraion
for file in $searchFolder/*
do
    ./search $file $searchFolder $outputPath 
done