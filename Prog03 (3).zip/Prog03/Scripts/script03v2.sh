#!/bin/bash
#runs the build script
Scripts/build.sh
imageInput=$1
searchFolder=$2
outputPath=$3

# Checks the amount of arguments
if [ $# -ne 3 ]; then
  echo "Incorrect amount of inputs."
  exit 1
fi

# Makes the output directory
mkdir "${outputPath}"

# For loop that goes through the directory and their files in a recursive manner
for file in $searchFolder/*
do
    # Checks if its within a directory
    if [[ -d $file ]]; 

    # If so, it will call the function again with the
    # new file path
    then
        $0 $imageInput $file $outputPath
    # else, it will continue the function as normal
    else
        ./search $file $searchFolder $outputPath
    fi
done