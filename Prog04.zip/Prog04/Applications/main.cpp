#include <iostream>
#include <list>
#include <string>

#include "mallocChoice.h"
#include "replacementManager.h"

int main(int argc, const char** arg) {
    
    // If statements ensure that a fit option was chosen
    // either being FIRST_FIT or BEST_FIT
    if(ALGORITHM_CHOICE != FIRST_FIT && ALGORITHM_CHOICE != BEST_FIT){
        std::cout << "Please select a fit option by typing it in after the ALGORITHM_CHOICE macro in mallocChoice.h" << std::endl;
        return 0;
    }

    // Runs initManager, as well as 
    // user defined malloc functionalities
    initManager();
    char* a = (char*) malloc(5000);
    free(a);

    return 0;
}