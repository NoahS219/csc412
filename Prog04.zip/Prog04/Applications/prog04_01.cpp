#include <iostream>
#include <vector>
#include <string>
#include <fstream> // fstream and sstream used to parse
#include <sstream> // and read from files (i.e. runSeq1.txt)
#include "replacementManager.h"
#include "mallocChoice.h"

int main(int argc, char* argv[]) {
    
    // Run's initManager
    initManager();

    // Ensures enough inputs are given
    if (argc <= 1) {
        std::cout << "Wrong amount of input" << std::endl;
        return 1;
    }

    // Finds the sequence_file based if "-v"
    // was input or not, as well as changing the
    // verbose macro if "-v" was included
    std::string sequence_file;
    if (std::string(argv[1]) == "-v" && argc == 3) {
        sequence_file = argv[2];
        #undef REPLACEMENT_MANAGER_VERBOSE
        #define REPLACEMENT_MANAGER_VERBOSE 1
    } 
    else {
        sequence_file = argv[1];
        #undef REPLACEMENT_MANAGER_VERBOSE
        #define REPLACEMENT_MANAGER_VERBOSE 0
    }

    // Infile is created to read in the file
    // by reading in sequence_file, and checks
    // to see if it's been opened or not by comparing
    // infile.is_open to 0, claiming it was unable to
    // open said file and closing it if unable    
    std::ifstream infile(sequence_file);
    if ((infile.is_open()) == 0) {
        std::cout << "Unable to open input file" << std::endl;
        return 0;
    }

    // string textcommand will help in reading
    // lines from the infile, with blocks storing
    // pointers allocated via malloc
    std::string textCommand;
    std::vector<void*> blocks;

    // While loop goes through each line from infile and
    // stores the textCommand string to break it up into
    // separate values, comparing them against characters and
    // utilizing my malloc/free functionalities
    while (std::getline(infile, textCommand)) {
        
        // codeLine captures the line from runSeq and
        // the command/value alongside with it
        std::istringstream codeLine(textCommand);
        std::string command;
        int value;

        // While loop extracts the inital command (m/f) and
        // uses it's numeric value in order to utilize and
        // execute malloc & free functionalities
        while (codeLine >> command >> value) {

            // If the command is "m", it will call malloc(myMalloc)
            // in order to carry out the memory allocation functionality
            if (command == "m") {
                void* currentBlock = malloc(value);
                if (currentBlock == nullptr) {
                    std::cout << "There is not enough memory to support " << value << " blocks of memory" << std::endl;
                } 
                else {
                    blocks.push_back(currentBlock);
                }
            } 
            
            // If the command is "f", it will call free(myFree)
            // in order to carry out the memory freeing functionality
            if (command == "f") {
                if (value >= 0 && value < blocks.size()) {
                    free(blocks[value]);
                    blocks[value] = nullptr;
                } 
                else {
                    std::cout << "Block index " << value << " is invalid" << std::endl;
                }
            }
        }
    }

    // closes the file
    infile.close();

    // The final section here frees up
    // all blocks with unallocated space
    for (int i = 0; i < blocks.size(); i++) {
        void* blockValue = blocks[i];
        if (blockValue != nullptr) {
            free(blockValue);
        }
    }
    
    return 0;
}