var searchData=
[
  ['initmanager_2',['initManager',['../replacement_manager_8h.html#a6448df822cbc59a7b0e1ed49e5857dc8',1,'replacementManager.h']]]
];
