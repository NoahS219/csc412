var searchData=
[
  ['replacementmalloc_2eh_6',['replacementMalloc.h',['../replacement_malloc_8h.html',1,'']]],
  ['replacementmanager_2eh_7',['replacementManager.h',['../replacement_manager_8h.html',1,'']]],
  ['replctfree_8',['replctFree',['../replacement_manager_8h.html#ace4e2f3a3d063ce32dbdadd4c1369f4b',1,'replacementManager.h']]],
  ['replctmalloc_9',['replctMalloc',['../replacement_manager_8h.html#a21c764baea13d69fe8a96134fe4084c4',1,'replacementManager.h']]]
];
