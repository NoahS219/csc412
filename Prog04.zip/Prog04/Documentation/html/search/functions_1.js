var searchData=
[
  ['myfree_14',['myFree',['../replacement_malloc_8h.html#aef8b39b5142716dd35e584f965c09d78',1,'replacementMalloc.h']]],
  ['mymalloc_15',['myMalloc',['../replacement_malloc_8h.html#a1cf0dcab156e591766b4a79a714e312b',1,'replacementMalloc.h']]]
];
