var searchData=
[
  ['printheapmap_16',['printHeapMap',['../replacement_manager_8h.html#a4686fcc6fa97337a52197c790a13cc99',1,'replacementManager.h']]]
];
