var searchData=
[
  ['replctfree_17',['replctFree',['../replacement_manager_8h.html#ace4e2f3a3d063ce32dbdadd4c1369f4b',1,'replacementManager.h']]],
  ['replctmalloc_18',['replctMalloc',['../replacement_manager_8h.html#a21c764baea13d69fe8a96134fe4084c4',1,'replacementManager.h']]]
];
