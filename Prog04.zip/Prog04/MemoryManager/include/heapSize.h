#ifndef HEAP_SIZE_H
#define HEAP_SIZE_H
#define HEAPSIZE	5000	// for example
#endif //	HEAP_SIZE_H