#ifndef REPLACEMENT_MALLOC_H
#define REPLACEMENT_MALLOC_H
#include <cstddef>

/** Function "myMalloc" is a void pointer that has the argument of size_t size
 *  being a void function, it's functionality is to use size and enact as the function
 *  call to the further function replctMalloc
 * 
 * @param size using size_t to represent bytes, size are the 
 *             number of bytes to be allocated by my malloc function
 */ 
void* myMalloc(size_t size);

/** Function "myFree" is a void that has the argument of void* ptr
 *  being a void function, it's functionality is to use memory blocks
 *  represented by ptr to free up memory. It is further implemented
 *  within its call to replctFree.
 * 
 * @param ptr using ptr, it helps "point" to an spot in memory that
 *            is addressed and accessed later within my code
 */ 
void myFree(void* ptr);

#endif