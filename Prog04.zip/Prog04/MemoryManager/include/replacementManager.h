#include "heapSize.h"
#include <cstddef>

/** Function "replctMalloc" is a void pointer that has the argument of size_t size.
 *  being a void function, it's functionality is to use size (being the number of bytes)
 *  to help allocate that many number of bytes
 * 
 * @param size using size, it helps create the size(in bytes) to create the memory
 *             allocation
 * 
 * @return pointer to the address currentBlock or nullpointer if nothing was found
 */ 
void* replctMalloc(size_t size);

/** Function "replctFree" is a void that has the argument of void* addr
 *  being a void function, it's functionality is to free blocks of
 *  memory when called
 * 
 * @param addr using addr, it helps "point" to an spot in memory that
 *             will need to be released
 */ 
void replctFree(void* addr);


/** Function "initManager" is a custom-user defined memory system. This
 *  function helps by creating a personalized state of the memory heap
 *  and allocates memory
 * 
 * @return true once called or false if there were any errors
 */ 
bool initManager();


/** Function "printHeapMap" is a void that has the functionality of
 *  printing the state of the memory heap, displaying information such as 
 *  the address, size, and if the spots been allocated or not
 */ 
void printHeapMap();