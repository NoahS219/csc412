#include "replacementMalloc.h"
#include "replacementManager.h"
#include "mallocChoice.h"

// myMalloc custom functionality that
// essentially calls upon replctMalloc
// and performs my custom made malloc
void* myMalloc(size_t size){
    void* addr = replctMalloc(size);
    #if REPLACEMENT_MANAGER_VERBOSE
        printHeapMap();
    #endif
    return addr;
}

// myFree custom functionality that
// essentially calls upon replctFree
// and performs my custom made Free
void myFree(void* addr){
    replctFree(addr);
    #if REPLACEMENT_MANAGER_VERBOSE
        printHeapMap();
    #endif
}