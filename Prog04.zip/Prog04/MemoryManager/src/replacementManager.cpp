#include <list>
#include <iostream>
#include <string>
#include "replacementMalloc.h"
#include "heapSize.h"
#include "mallocChoice.h"

// MemoryElement structure that
// will store the memory address,
// if the spot is allocated or not
// as well as the size of said spot
struct MemoryElement {
    void* address; 
    bool isAlloc;
    size_t size;
};

// initManager is called, as well as 
// having the heap we operate on declared
// and the heapStartAddr as well
std::list<MemoryElement> heap;
void* heapStartAddr;
bool initManager();

// My own personal replacementMalloc function
// that takes in the given size, and uses it in
// order to find any spaces within a given heap size
void* replctMalloc(size_t size) {
    std::list<MemoryElement>::iterator currentBlock = heap.end();

    // If "ALGORITHM_CHOICE" was selected as "FIRST_FIT"
    // then iterate through loop containing elements of
    // MemoryElement. Checks to see if currentMemory block
    // is allocated or not, as well as current i size is greater
    // than the defined size, setting currentBlock to i and breaking if not
    if(ALGORITHM_CHOICE == FIRST_FIT){
        for (std::list<MemoryElement>::iterator i = heap.begin(); i != heap.end(); i++) {
            if (i->isAlloc == false && i->size >= size) {
                currentBlock = i;
                break;
            }
        }
    }

    // If "ALGORITHM_CHOICE" was selected as "BEST_FIT"
    // then best_fit_size is initialized in order to represent
    // the max size. Then by iterating through the elements of 
    // the list, until the end is reached, set the best_fit_size to
    // the current struct size of i if isAlloc is false and the current
    // memory size of i is less than best_fit_size
    if (ALGORITHM_CHOICE == BEST_FIT) {
        size_t best_fit_size = SIZE_MAX;
        for (std::list<MemoryElement>::iterator i = heap.begin(); i != heap.end(); i++) {
            if (i->isAlloc == false && i->size >= size && i->size < best_fit_size) {
                best_fit_size = i->size;
                currentBlock = i;
            }
        }
    } 

    // Now once the memory block allocation has been found,
    // this code will allocate the memory created previously in
    // the previous statements

    // By checking if the currentBlock is NOT pointing to
    // end end of the heap, we can determine a memoryBlock was found
    // setting currentBlock-> isAlloc to true marks it as an allocated
    // memory block.
    if (currentBlock != heap.end()) {
        currentBlock->isAlloc = true;

        // Now checking if currentBlock is large enough to be split
        // to a new memory block by seeing if currentBlock.size is greater
        // than MemoryElement. If met, newElement is created to act
        // as said memory block, and is set to be the size of the difference
        // between currentBlock, and the userRequested size. Is set to the heap after
        // and is updated. Current block is updated
        if (currentBlock->size >= size + sizeof(MemoryElement)) {
            void* newAddress = (char*)currentBlock->address + size;
            MemoryElement newElement = {newAddress, false, currentBlock->size - size};
            currentBlock->size = size;
            heap.insert(std::next(currentBlock), newElement);
        }
        return currentBlock->address;
    }
    // Returns nullPointer if the currentBlock DOES equal the
    // end of the heap
    return nullptr;
}

// My own personal replacementFree function
// that takes in the given address, and uses it in
// order to merge blocks, removing empty spaces
void replctFree(void* addr) {
    std::list<MemoryElement>::iterator i = heap.begin();
    for (std::list<MemoryElement>::iterator i = heap.begin(); i != heap.end(); i++) {
        if (i->address == addr) {
            break;
        }
    }

    // The statements beneath will help determine
    // which block it should merge with if it's free
    if (i != heap.end()) {
        i->isAlloc = false;

        // Checks to see if the previous block is
        // free, and merges with it if so
        if (i != heap.begin()) {
            std::list<MemoryElement>::iterator previousBlock = std::prev(i);
            if (previousBlock->isAlloc == 0) {
                previousBlock->size += i->size;
                i = heap.erase(i);
                i = previousBlock;
            }
        }

        // Checks to see if the next block is
        // free, and merges with it if so
        std::list<MemoryElement>::iterator next = std::next(i);
        if (next != heap.end() && !next->isAlloc) {
            i->size += next->size;
            heap.erase(next);
        }
    }
}

// printHeapMap function that helps print out all 
// of the Free/Not Free blocks, as well as their 
// memory address and size
void printHeapMap() {
    for (std::list<MemoryElement>::const_iterator i = heap.begin(); i != heap.end(); i++) {
        const MemoryElement element = *i;
        std::cout << "Address: " << element.address << std::endl;
        std::cout << "Size: " << element.size << std::endl;
        std::cout << "Status: ";
        if(element.isAlloc == 0){
            std::cout << "Full" << std::endl;
        }
        if(element.isAlloc == 1){
            std::cout << "Free" << std::endl;
        }
        std::cout << " " << std::endl;
    }
}

// initManager acts as the initalization manager for the code's functionality
// helps test against values within the heap list we work with.
bool initManager() {
    heapStartAddr = malloc(HEAPSIZE);

    MemoryElement initialElement = {heapStartAddr, false, HEAPSIZE};
    heap.push_back(initialElement);

    printHeapMap();
    return true;
}
