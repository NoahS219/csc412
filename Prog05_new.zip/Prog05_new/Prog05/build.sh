g++ -Wall -std=c++2a Version1/main.cpp Version1/gl_frontEnd.cpp -lGL -lglut -lpthread -o v1
g++ -Wall -std=c++2a Version2/main.cpp Version2/gl_frontEnd.cpp -lGL -lglut -lpthread -o v2
g++ -Wall -std=c++2a Version3/main.cpp Version3/gl_frontEnd.cpp -lGL -lglut -lpthread -o v3