//
//  main.cpp
//  GL travelers
//
//  Created by Jean-Yves Hervé
//	C++ version eevised 2023-04-12

/*-------------------------------------------------------------------------+
 |	A graphic front end for a grid+state simulation.						|
 |																			|
 |	This application simply creates a glut window with a pane to display	|
 |	a colored grid and the other to display some state information.			|
 |																			|
 |	Current GUI:															|
 |		- 'ESC' --> exit the application									|
 |		- 'r' --> add red ink												|
 |		- 'g' --> add green ink												|
 |		- 'b' --> add blue ink												|
 |																			|
 |	Created by Jean-Yves Hervé on 2017-04-24, revised 2023-04-17			|
 +-------------------------------------------------------------------------*/

#include <random>
#include <vector>
#include <cstdlib>
#include <ctime>
//
#include <thread>
#include <iostream>
#include "glPlatform.h"
#include "gl_frontEnd.h"

using namespace std;
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wswitch"
#pragma GCC diagnostic ignored "-Wsign-compare"

//==================================================================================
//	Function prototypes
//==================================================================================
void displayGridPane(void);
void displayStatePane(void);
void initializeApplication(void);
void travelerThread(TravelerInfo* traveler);

//==================================================================================
//	Application-level global variables
//==================================================================================

//	Don't touch
extern int	GRID_PANE, STATE_PANE;
extern int	gMainWindow, gSubwindow[2];
extern signed int SPEED_ALTERNATOR;
//	The state grid and its dimensions
int** grid;
int numRows, numCols, maxNumThreads;

//	the number of live threads (that haven't terminated yet)
int MAX_NUM_TRAVELER_THREADS = 10;
int numLiveThreads = 0;
bool DRAW_COLORED_TRAVELER_HEADS = true;

//	the ink levels
int MAX_LEVEL = 50;
int MAX_ADD_INK = 10;
int redLevel = 20, greenLevel = 10, blueLevel = 40;

//	ink producer sleep time (in microseconds)
//	[min sleep time is arbitrary]
const int MIN_SLEEP_TIME = 30000;
int producerSleepTime = 100000;

vector<TravelerInfo> travelerList;

//==================================================================================
//	These are the functions that tie the simulation with the rendering.
//	Some parts are "don't touch."  Other parts need your intervention
//	to make sure that access to critical section is properly synchronized
//==================================================================================


void displayGridPane(void)
{
	//	This is OpenGL/glut magic.  Don't touch
	glutSetWindow(gSubwindow[GRID_PANE]);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//---------------------------------------------------------
	//	This is the call that makes OpenGL render the grid.
	//
	//	You *must* synchronize this call.
	//---------------------------------------------------------
	//	drawGrid(grid, numRows, numCols);

	//	Use this drawing call instead
	drawGridAndTravelers(grid, numRows, numCols, travelerList);
	
	//	This is OpenGL/glut magic.  Don't touch
	glutSwapBuffers();
	glutSetWindow(gMainWindow);
}

void displayStatePane(void)
{
	//	This is OpenGL/glut magic.  Don't touch
	glutSetWindow(gSubwindow[STATE_PANE]);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	//---------------------------------------------------------
	//	This is the call that makes OpenGL render information
	//	about the state of the simulation.
	//
	//	You *must* synchronize this call.
	//
	//---------------------------------------------------------
	drawState(numLiveThreads, redLevel, greenLevel, blueLevel);
		
	//	This is OpenGL/glut magic.  Don't touch
	glutSwapBuffers();
	glutSetWindow(gMainWindow);
}

//------------------------------------------------------------------------
//	These are the functions that would be called by a traveler thread in
//	order to acquire red/green/blue ink to trace its trail.
//	You *must* synchronize access to the ink levels
//------------------------------------------------------------------------
//
bool acquireRedInk(int theRed)
{
	bool ok = false;
	if (redLevel >= theRed)
	{
		redLevel -= theRed;
		ok = true;
	}
	return ok;
}

bool acquireGreenInk(int theGreen)
{
	bool ok = false;
	if (greenLevel >= theGreen)
	{
		greenLevel -= theGreen;
		ok = true;
	}
	return ok;
}

bool acquireBlueInk(int theBlue)
{
	bool ok = false;
	if (blueLevel >= theBlue)
	{
		blueLevel -= theBlue;
		ok = true;
	}
	return ok;
}

//------------------------------------------------------------------------
//	These are the functions that would be called by a producer thread in
//	order to refill the red/green/blue ink tanks.
//	You *must* synchronize access to the ink levels
//------------------------------------------------------------------------
//
bool refillRedInk(int theRed)
{
	bool ok = false;
	if (redLevel + theRed <= MAX_LEVEL)
	{
		redLevel += theRed;
		ok = true;
	}
	return ok;
}

bool refillGreenInk(int theGreen)
{
	bool ok = false;
	if (greenLevel + theGreen <= MAX_LEVEL)
	{
		greenLevel += theGreen;
		ok = true;
	}
	return ok;
}

bool refillBlueInk(int theBlue)
{
	bool ok = false;
	if (blueLevel + theBlue <= MAX_LEVEL)
	{
		blueLevel += theBlue;
		ok = true;
	}
	return ok;
}

//------------------------------------------------------------------------
//	You shouldn't have to touch this one.  Definitely if you don't
//	add the "producer" threads, and probably not even if you do.
//------------------------------------------------------------------------
void speedupProducers(void)
{
	//	decrease sleep time by 20%, but don't get too small
	int newSleepTime = (8 * producerSleepTime) / 10;
	
	if (newSleepTime > MIN_SLEEP_TIME)
	{
		producerSleepTime = newSleepTime;
	}
}

void slowdownProducers(void)
{
	//	increase sleep time by 20%
	producerSleepTime = (12 * producerSleepTime) / 10;
}


// function "travelerInfo" helps introduce the traveelrs information
// to the travelerInfo vector. In there, each traveler has their own type
// position, direction, as well as their status. 
void travelerInfo(vector<TravelerInfo>& travelerList, int numTravelers, int numRows, int numCols) {
	// helps set up randomly generated number that 
	// specifies integervalues which correclate to different actions
	// the 0 1 2 3 translates to north east south and west respectively
    random_device myRandDev;
    default_random_engine myEngine(myRandDev());
    uniform_int_distribution<int> distance(0, 2); 
    uniform_int_distribution<int> totalRowCount(1, numRows - 2);
    uniform_int_distribution<int> totalColCount(1, numCols - 2);
    uniform_int_distribution<int> direction(0, 3);

	// While loop generates the randomized traveler information
	// and appends it to the travelerinformation vector until
	// the total number of travelers have been addressed
    int counter = 0;
    while (counter < numTravelers) {
        TravelerInfo travelingMan;
        travelingMan.type = static_cast<TravelerType>(distance(myEngine));
        travelingMan.row = totalRowCount(myEngine);
        travelingMan.col = totalColCount(myEngine);
        travelingMan.dir = static_cast<TravelDirection>(direction(myEngine));
        travelingMan.isLive = true;

        // For statement then checks if the position is unique by
		// comparing it with the other positions within the list
        bool uniquePos = true;
		for (int i = 0; i < travelerList.size(); i++) {
			if (travelingMan.row == travelerList[i].row && travelingMan.col == travelerList[i].col) {
				uniquePos = false;
				break;
			}
		}

        // Adds the traveler info to the total list 
		// if the generated position is unique
        if (uniquePos == true) {
            travelerList.push_back(travelingMan);
            counter++;
        }
    }
}

//------------------------------------------------------------------------
//	You shouldn't have to change anything in the main function
//------------------------------------------------------------------------
int main(int argc, char** argv){
	// Ensures enough input are given --------------------------------------------------------------------------------
	if (argc != 4){
		std::cout <<"The width, height, and desired number of computation threads are required."<<std::endl;
		std::cout <<"The input must be positive, larger than the number 5, and the number of threads must not be larger than the height of the grid"<<std::endl;
		exit(1);
	}
	// declares width, height, and threadNum as variables
	numCols= atoi(argv[1]); //width
	numRows = atoi(argv[2]); //height
	maxNumThreads = atoi(argv[3]); // amount of threads created
	// ensures rows and columns are higher than 5
	if (numRows < 5 || numCols < 5){
		std::cout <<"The width, and height must be a value higher than 5."<<std::endl;
		exit(1);
	}
	// ensures maximum number of threads is less than number of columns
	if (maxNumThreads > numRows){
		std::cout <<"The maximum number of threads must not be higher than the column size"<<std::endl;
		exit(1);
	}

    initializeFrontEnd(argc, argv, displayGridPane, displayStatePane);

    // Now we can do application-level
    initializeApplication();

    // creates the starting thread vector which will be
	// used in order to hold the other traveler threads.
	// in the loop, the travelerThread function is passed,
	// and has information pushed back to the travelerThread
	// function
	numLiveThreads = travelerList.size();
	std::vector<std::thread> travelerThreads;
	for (int i = 0; i < travelerList.size(); i++) {
		travelerThreads.push_back(std::thread(travelerThread, &travelerList[i]));
	}

    //	Now we enter the main loop of the program and to a large extend
	//	"lose control" over its execution.  The callback functions that 
	//	we set up earlier will be called when the corresponding event
	//	occurs
	glutMainLoop();

    // helps the traveler threads join together
    for (int i = 0; i < travelerThreads.size(); ++i) {
    	travelerThreads[i].join();
	}

    // in fact never called.
    cleanupAndQuit();

    // This will never be executed (the exit point will be in one of the
    // call back functions).
    return 0;
}


//==================================================================================
//
//	This is a part that you have to edit and add to.
//
//==================================================================================


void cleanupAndQuit()
{
	//	You would want to join all the threads before you free the grid and other
	//	allocated data structures.  You may run into seg-fault and other ugly termination
	//	issues otherwise.
	
	//	just nicer.  Also, if you crash there, you know something is wrong
	//	in your code.
	for (int i=0; i< numRows; i++)
		delete []grid[i];
	delete []grid;

	//	clear the traveler list
	exit(0);
}

// function travelerThread will help the movement of a tracker
// on the grid. It will help in the specifications of what it
// can/cannot do, and how long it will love for
void travelerThread(TravelerInfo *traveler) {
    while (traveler->isLive) {
        int newRow = traveler->row;
        int newCol = traveler->col;

		// helps update the travelers position
		// adding/subtracting 1 in order to simulate
		// where it will traverse within the grid
        switch (traveler->dir) {
            case NORTH:
                newRow--;
                break;
            case EAST:
                newCol++;
                break;
            case SOUTH:
                newRow++;
                break;
            case WEST:
                newCol--;
                break;
        }

        // Ensure position is within the grid
        if (newRow >= 0 && newRow < numRows && newCol >= 0 && newCol < numCols) {

            // Based on the traveler, it will
			// change the grid color to red, 
			// green, or blue respectively
            if (traveler->type == RED_TRAV) {
                grid[traveler->row][traveler->col] = 0xFFFF0000;
            } else if (traveler->type == GREEN_TRAV) {
                grid[traveler->row][traveler->col] = 0xFF00FF00;
            } else if (traveler->type == BLUE_TRAV) {
                grid[traveler->row][traveler->col] = 0xFF0000FF;
            }
			// update traveler information
            traveler->row = newRow;
            traveler->col = newCol;
        }

        // This will cancel the thread out if it reaches any of the four corners
        if ((newRow == 0 && newCol == 0) || (newRow == 0 && newCol == numCols - 1) || (newRow == numRows - 1 && newCol == 0) || (newRow == numRows - 1 && newCol == numCols - 1)) {
            traveler->isLive = false;
            continue;
        }

        // This will change the current thread's direction
		// once it reaches the edge of the grid
        if (newRow == 0 && traveler->dir == NORTH) {
            traveler->dir = EAST;
        } 
		else if (newCol == numCols - 1 && traveler->dir == EAST) {
            traveler->dir = SOUTH; 
        } 
		else if (newRow == numRows - 1 && traveler->dir == SOUTH) {
            traveler->dir = WEST; 
        } 
		else if (newCol == 0 && traveler->dir == WEST) {
            traveler->dir = NORTH; 
        }

        // Allows to control the speed at which
		// the threads are moving at
        std::this_thread::sleep_for(std::chrono::milliseconds(SPEED_ALTERNATOR));
    }

    // Decrease the number of live threads when a traveler is terminated
    numLiveThreads--;
}



void initializeApplication(void)
{
	//	Allocate the grid
	grid = new int*[numRows];
	for (int i=0; i<numRows; i++)
		grid[i] = new int[numCols];
	
	//---------------------------------------------------------------
	//	The code block below to be replaced/removed
	//	I initialize the grid's pixels to have something to look at
	//---------------------------------------------------------------
	//	Random generator for the initial colors
	//	The initial cell color generation code should go away, but you
	//	should use tese for position and traveler type generation.
	random_device myRandDev;
	default_random_engine myEngine(myRandDev());
	//	I don't want my squares to be too dark
	const unsigned char minVal = (unsigned char) 40;
	//	I create my random distribution local to this function because
	//		1. It's used only once in the program's lifetime, here.
	//		2. This code is meant to go away.
	uniform_int_distribution<unsigned char> colorDist(minVal, 255);
	
	//	create RGB values (and alpha  = 255) for each pixel
	for (int i=0; i<numRows; i++)
	{
		for (int j=0; j<numCols; j++)
		{
			//	temp code to get some color initially
			unsigned char red = colorDist(myEngine);
			unsigned char green = colorDist(myEngine);
			unsigned char blue = colorDist(myEngine);
			grid[i][j] = 0xFF000000 | (blue << 16) | (green << 8) | red;
			
			//makes back of board black
			for (int i=0; i<numRows; i++) {
        		for (int j=0; j<numCols; j++) {
            		grid[i][j] = 0xFF000000;
        		}
    		}
		}
	}

	grid[0][0] = 0xFF000000;
	
	//---------------------------------------------------------------
	//	You're going to have to properly initialize your travelers at random locations
	//	on the grid:
	//		- not at a corner
	//		- not at the same location as an existing traveler
	//---------------------------------------------------------------
//
//	for (int k=0; k< MAX_NUM_TRAVELER_THREADS; k++)
//	{
//		type = <random type>;
//		row = <random start location>;
//		col = <random start location>;
//		dir = <random start direction>;
//		isLive = true;
//	}
    // Creates the other travelers, specified by the user
    travelerInfo(travelerList, maxNumThreads, numRows, numCols);
}
#pragma GCC diagnostic pop