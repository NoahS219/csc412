#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include "operations.h"
#include "rasterImage.h"
#include "imageIO_TGA.h"

// crop.c is responsible for cropping an image starting on
// a user given row and column axis, as well as a "cropping range"
int main(int argc, char *argv[]){

    //checks conditions
    if(argc < 7 || argc > 7){
        printf("The amount of inputs are incorrect \n");
        exit(1);
    }
    // Loads in filePathing to check if it
    // exists in the given image path
    FILE* tga_in = fopen(argv[1], "rb" );
    int fileDetermine = 0;
	if (tga_in == NULL){
        fileDetermine = 1;
	}

    // This code checks to see if there is a ".tga" at the end of the given file
    if(argv[1][strlen(argv[1])-1] != 'a' || argv[1][strlen(argv[1]) - 2] != 'g' || argv[1][strlen(argv[1])-3] != 't' || argv[1][strlen(argv[1])-4] != '.'){
        int cropName = 0;
        int cropNameArray[strlen(argv[1])];

        // Finds the name until it reaches the first "/" of the
        // array and writes it backwards, as well as creating a
        // variable which will help the next loop start at the end
        while(argv[1][strlen(argv[1]) - cropName] != 47){
            cropNameArray[cropName] = argv[1][strlen(argv[1]) - cropName];                
            cropName += 1;
        }

        // Prints that the arguement is not a tga
        // file if it matches the conditions and
        // prints out the array of the given input
        printf("The argument is not a tga file: ");
        for(int i = cropName-1; i >= 0; i--){
            printf("%c", cropNameArray[i]);
        }
        printf("\n");
        exit(1);
    }

    // This conditional statement checks if it isn't
    // within the input file and reports back that
    // it's unable to open the image file
    if(fileDetermine == 1){
        int cropName = 0;
        int cropNameArray[strlen(argv[1])];

        // Finds the folder name right before the "/"
        while(argv[1][strlen(argv[1]) - cropName] != 47){
            cropNameArray[cropName] = argv[1][strlen(argv[1]) - cropName];
            cropName += 1;
        }

        // Prints out it cannot open the image file
        // and proceeds to print out the input it's
        // unable to open
        printf("Cannot open image file: ");
        for(int i = cropName-1; i >= 0; i--){
            printf("%c", cropNameArray[i]);
        }
        printf("\n");
        exit(1);
    }

    // Runs cropImage found in operations
    cropImage(argc, argv);

    return 0;
}