#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include "operations.h"
#include "rasterImage.h"
#include "imageIO_TGA.h"

// This function "displayWrongFile" checks to see if there is a ".tga"
// at the end of the given file
void displayWrongFile(int argc, char* argv[], int fileDetermine){
    if(argv[argc][strlen(argv[argc])-1] != 'a' || argv[argc][strlen(argv[argc]) - 2] != 'g' || argv[argc][strlen(argv[argc])-3] != 't' || argv[argc][strlen(argv[argc])-4] != '.'){
        int fileName = 0;
        int fileNameArray[strlen(argv[argc])];

        // Finds the name until it reaches the first "/" of the
        // array and writes it backwards, as well as creating a
        // variable which will help the next loop start at the end
        while(argv[argc][strlen(argv[argc]) - fileName] != 47){
            fileNameArray[fileName] = argv[argc][strlen(argv[argc]) - fileName];
            fileName += 1;
        }
        // Prints that the arguement is not a tga
        // file if it matches the conditions and
        // prints out the array of the given input
        printf("The argument is not a tga file: ");
        for(int i = fileName-1; i >= 0; i--){
            printf("%c", fileNameArray[i]);
        }
        printf("\n");
        exit(1);
    }

    // This conditional statement checks if it isn't
    // within the input file and reports back that
    // it's unable to open the image file
    if(fileDetermine == 1){
        int fileName = 0;
        int fileNameArray[strlen(argv[argc])];

        // Finds the folder name right before the "/"
        while(argv[argc][strlen(argv[argc]) - fileName] != 47){
            fileNameArray[fileName] = argv[argc][strlen(argv[argc]) - fileName];
            fileName += 1;
        }

        // Prints out it cannot open the image file
        // and proceeds to print out the input it's
        // unable to open
        printf("Cannot open image file: ");
        for(int i = fileName-1; i >= 0; i--){
            printf("%c", fileNameArray[i]);
        }
        printf("\n");
        exit(1);
    }
}

// dimensions.c is responsible for receiving a file input
// and then displaying the file information if it matches
// the given criteria
int main(int argc, char *argv[]){
    // If the argument count is less than 2
    // then produce that file cannot be read
    if (argc < 2){
        printf("File cannot be read\n");
        exit(1);
    }

    // If the argument count is greater than or
    // equal to 4 then produce that file cannot 
    // be read
    if(argc >= 4){
        printf("Multiple modifier chains not allowed.\n");
        exit(1);
    }
    
    RasterImage image;
    // If argc == 3, set images to this specific filepath name
    if(argc == 3){
        // Loads in filePathing to check if it
        // exists in the given image path
        FILE* tga_in = fopen(argv[2], "rb" );
        int fileDetermine = 0;
	    if (tga_in == NULL){
            fileDetermine = 1;
	    }
        // Runs code through display wrong file
        displayWrongFile(argc-1, argv, fileDetermine);
        
        // Gives image it's filepath name
        image = readTGA(argv[2]);
    }

    // Loads in filePathing to check if it
    // exists in the given image path
    if(argc == 2){
        FILE* tga_in = fopen(argv[1], "rb" );
        int fileDetermine = 0;
	    if (tga_in == NULL){
            fileDetermine = 1;
	    }
        // Runs code through display wrong file
        displayWrongFile(argc-1, argv, fileDetermine);
        
        // Gives image it's filepath name
        image = readTGA(argv[1]);
    }

    // Calls "getDimensions" which will perform calculations to
    // get the dimensions
    getDimensions(&image, argc, argv);
    return 0;
}