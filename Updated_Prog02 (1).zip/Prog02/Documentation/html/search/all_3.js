var searchData=
[
  ['getdimensions_4',['getDimensions',['../operations_8h.html#a27e5e2ac9fe3c8f700a1ce3e23db0b86',1,'operations.h']]],
  ['gray_5fraster_5',['GRAY_RASTER',['../raster_image_8h.html#a3154c405c975616503bac23f51b78fc0a1bf07d3a75c4324ba940a18663b4f5e9',1,'rasterImage.h']]]
];
