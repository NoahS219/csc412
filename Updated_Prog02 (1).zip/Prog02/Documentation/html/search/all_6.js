var searchData=
[
  ['newimage_10',['newImage',['../raster_image_8h.html#a729402985cbea7207fa8b3c8bfd61dc1',1,'rasterImage.h']]]
];
