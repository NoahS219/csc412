var searchData=
[
  ['operations_2eh_11',['operations.h',['../operations_8h.html',1,'']]]
];
