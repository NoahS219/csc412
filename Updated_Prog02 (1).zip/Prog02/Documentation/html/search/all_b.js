var searchData=
[
  ['tga_5fcolor_5ffile_21',['TGA_COLOR_FILE',['../raster_image_8h.html#ae9c64aca475ec964f3c00355a43fa4a2aaca351673a7a0bc316b95835d352ff2d',1,'rasterImage.h']]],
  ['tga_5fgray_5ffile_22',['TGA_GRAY_FILE',['../raster_image_8h.html#ae9c64aca475ec964f3c00355a43fa4a2ab1db74124c4b9195b34f1617a9925526',1,'rasterImage.h']]],
  ['type_23',['type',['../struct_raster_image.html#a4479a994a2f19c14d9c68a19c9d8061c',1,'RasterImage']]]
];
