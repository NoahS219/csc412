var searchData=
[
  ['unknown_5fimage_5ffile_5ftype_24',['UNKNOWN_IMAGE_FILE_TYPE',['../raster_image_8h.html#ae9c64aca475ec964f3c00355a43fa4a2a71ec81110c7febec8a458d56ef5cdc30',1,'rasterImage.h']]]
];
