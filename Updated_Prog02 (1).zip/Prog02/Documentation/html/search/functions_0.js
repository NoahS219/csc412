var searchData=
[
  ['cropimage_31',['cropImage',['../operations_8h.html#a5a90a22b4755cd76c4895979e237496f',1,'operations.h']]]
];
