var searchData=
[
  ['getdimensions_32',['getDimensions',['../operations_8h.html#a27e5e2ac9fe3c8f700a1ce3e23db0b86',1,'operations.h']]]
];
