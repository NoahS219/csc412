var searchData=
[
  ['readtga_34',['readTGA',['../image_i_o___t_g_a_8h.html#ac14241b28d552ac963255d74760e7929',1,'imageIO_TGA.h']]],
  ['rotationfunction_35',['rotationFunction',['../operations_8h.html#aa5b1ee346ac4e1aa27fdfe5c6541dedc',1,'operations.h']]]
];
