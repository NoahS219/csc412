var searchData=
[
  ['splitfunctionality_36',['splitFunctionality',['../operations_8h.html#acd6d0bd2770c4ab22f961e6c90a5ec77',1,'operations.h']]]
];
