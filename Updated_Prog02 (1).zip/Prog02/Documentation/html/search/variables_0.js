var searchData=
[
  ['bytesperpixel_38',['bytesPerPixel',['../struct_raster_image.html#a07838a57d442a921e0515f67c0092979',1,'RasterImage']]],
  ['bytesperrow_39',['bytesPerRow',['../struct_raster_image.html#a149ca55ed5a4afa03eba3897e6ef09d6',1,'RasterImage']]]
];
