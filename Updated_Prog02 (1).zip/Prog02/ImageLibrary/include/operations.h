#include "rasterImage.h"
#include "imageIO_TGA.h"
/** Function "getDimensions" is instantiated by a char string that is responsible for getting the dimensions of an 
 *  image. Based on it's given conditions, it will print out the images width and height, or width and height alone
 * 
 * @param image image is used for its ability grab the images width 
 *              and height and print it out due to the images request
 * 
 * @param argc Helps to determine if the given function will be
 *             given conditions to account for: (w = width) (h = height) (v = verbos).
 * 
 * @param argv argv is used to obtain the input path, and to receive the 
 *             previously stated w, h, v in order to base the proper output
 * 
 * @return 0
 */ 
char* getDimensions(RasterImage* image, int argc, char *argv[]);

/** Void function "splitFunctionality" is responsible for splitting up the images based on solo-color inputs. 
 * It soley needs a fileinput as well as a file output location
 * 
 * @param image The image obtained by calling upon raster. It's used for its ability to 
 *              visit each pixel and print them upon the second decared image in the function
 * 
 * @param argc The count of arguments placed in the command line. 
 *             Helps to determine what the input and output path are titled
 * 
 * @param argv The given position of each argument. This is used to
 *             obtain the input path, and to receive the output path as well
 */ 
void splitFunctionality(int argc, char* argv[]);

/** Void function "rotationFunction" is responsible for rotating the image based on the user input
 * 
 * @param image The image obtained by calling upon raster. It's used for its ability to 
 *              visit each pixel and print them upon the second decared image in the function.
 *              The second image will be the one rotated
 * 
 * @param argc The count of arguments placed in the command line. 
 *             Helps to determine what the input and output path are titled
 *             as wellas the rotating images location
 * 
 * @param argv The given position of each argument. This is used to
 *             obtain the input path, and to receive the output path as well
 *             Additionally, this will be taking in the rotation request
 */ 
void rotationFunction(int argc, char* argv[]);

/** Void function "cropImage" is responsible for cropping an image based on the
 *  user's specifications of a rowValue, colValue, and cropping image zone value
 * 
 * @param image The image obtained by calling upon raster. It's used for its ability to 
 *              visit each pixel and print them upon the second cropped image
 * 
 * @param argc The count of arguments placed in the command line. 
 *             Helps to determine what the input and output path are titled
 *             as well as additional values like rowValue, colValue, and the image crop zone
 * 
 * @param argv The given position of each argument. This is used to
 *             obtain the input path, output path, the rowValue and colValue
 *             coordinates of where to start on an image, as well
 *             as a cropping zone to receive from the image
 *
 */ 
void cropImage(int argc, char* argv[]);