#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "operations.h"
#include "rasterImage.h"
#include "imageIO_TGA.h"

// Operations.c is responsible for executing all of
// the given inputs and calculations that are managed
// and set for it through each functionalities files


// *****************************************************************
// *****************getDimensions function *************************
// *****************************************************************

// getDimensions is called from dimensions.c which will
// go through the given file and feedback a proper width or
// height from the image, as well as a width or height
// exclusive checker
char* getDimensions(RasterImage* image, int argc, char *argv[]) {

    // Checks to see if the function only called for the filename
    // input and nothing else conditionally
    if(argc == 2){
        printf("Width: %d, height: %d\n", image->width, image->height);
    }

    // If the filename exists along with flag identifier
    if(argc == 3){
        // It checks through all characters of the special key
        // and returns back if it's not w, h, v
        for(int i = 0; i < strlen(argv[1]); i++){
                if(argv[1][i] == 119 || argv[1][i] == 118 || argv[1][i] == 104 || argv[1][i] == 45){
                    continue;
                }
                else{
                    printf("Invalid Modifier: -%c\n", argv[1][i]);
                    exit(1);
                }
        }

        // Checks for arguments within the string length of arguement 1 (-wvh)
        for(int i = 0; i<strlen(argv[1]); i++){
            char opt = argv[1][i];
            while(opt != '-'){

                // Code runs through various cases that will enact
                // a solution in different ways, depending on what
                // it is given

                // It will also check for inputs infront and behind
                // it for any special case scenarios, since some
                // characters cannot be together
                switch(opt){
                    case 'v':
                            if((argv[1][i+1] == 'h' || argv[1][i+2] == 'h')){
                                printf("Height: %d\n", image->height);
                                exit(1);
                            }

                            else if((argv[1][i+1] == 'w' || argv[1][i+2] == 'w')){
                                printf("Width: %d\n", image->width);
                                exit(1);
                            }

                            else{
                            printf("Width: %d, height: %d\n", image->width, image->height);
                            exit(1);
                            }

                    case 'h':
                        if(argv[1][i-1] == 'w' || argv[1][i+1] == 'w' || argv[1][i-2] == 'w' || argv[1][i+2] == 'w'){
                            printf("Modifiers -w and -h cannot be used together.\n");
                            exit(1);
                        }
                        else{
                            printf("Height: %d\n", image->height);
                            exit(1);
                        }

                    case 'w':
                        if(argv[1][i-1] == 'h' || argv[1][i+1] == 'h' || argv[1][i-2] == 'h' || argv[1][i+2] == 'h'){
                            printf("Modifiers -w and -h cannot be used together.\n");
                            exit(1);
                        }
                        else{
                            printf("Width: %d\n", image->width);
                            exit(1);
                        }
                }
            }
        }
    }
    return 0;
}





// *****************************************************************
// *********************** colorFunctions **************************
// *****************************************************************

// splitFunctionality is called from split.c which will
// go through the given file and return three instances
// of a color, purly of their red, blue, and green values

// For this to work, three functions called
// "keepRedChannel" "keepBlueChannel" "keepGreenChannel"
// will operate, removing color values from the image

// keepRedChannel functions by removing the color
// from pixel values that aren't red (blue & green)
void keepRedChannel(RasterImage* image){
    int* raster = (int*)(image->raster);
    for(unsigned int i=0; i<image->height; i++){
        for (unsigned int j=0; j<image->width; j++){
            unsigned char* rgba = (unsigned char*) (raster + i*image->width + j);
            rgba[1] = 0x00;
            rgba[2] = 0x00;
        }
    }	
}

// keepGreenChannel functions by removing the color
// from pixel values that aren't red (blue & red)
void keepGreenChannel(RasterImage* image){
    int* raster = (int*)(image->raster);
	for(unsigned int i=0; i<image->height; i++){
		for (unsigned int j=0; j<image->width; j++){
			unsigned char* rgba = (unsigned char*) (raster + i*image->width + j);
			rgba[0] = 0x00;
            rgba[2] = 0x00;
		}
	}	
}

// keepBlueChannel functions by removing the color
// from pixel values that aren't red (red & green)
void keepBlueChannel(RasterImage* image){
    int* raster = (int*)(image->raster);
	for(unsigned int i=0; i<image->height; i++){
		for (unsigned int j=0; j<image->width; j++){
			unsigned char* rgba = (unsigned char*) (raster + i*image->width + j);
			rgba[0] = 0x00;
            rgba[1] = 0x00;
		}
	}	
}

// splitFunctionality's functionality is to intake
// a file and help separate it into 3 imgage values
// that will be one color only. It calls upon 
// keep color channels to execute this
void splitFunctionality(int argc, char* argv[]){
    int fileName = 0;
    int fileNameArray[strlen(argv[1])];
    
    // Finds the name until it reaches the first "/" of the
    // array and writes it backwards, as well as creating a
    // variable which will help the next loop start at the end
    while(argv[1][strlen(argv[1]) - fileName] != 47){
        fileNameArray[fileName] = argv[1][strlen(argv[1]) - fileName];
        fileName += 1;
    }

    // Sets up the array that holds the program name
    int difference = fileName;
    char differenceArray[160];    
    int differenceArrayAddition = 0;

    // This will put the filename onto an array,
    // and stops once a period is hit to avoid
    // printing a .tga
    for(int i = fileName-1; i >= 0; i--){
        if(differenceArrayAddition < difference){
            if(fileNameArray[i] == '.'){
                break;
            } 
        differenceArray[differenceArrayAddition] = fileNameArray[i];
        differenceArrayAddition += 1;
        }
    }

    // The next lines of code helps format the filename output properly
    char* fileOutput = argv[2]; // Gets the ./output line
    char fileOutput2[150];
    char fileOutput3[150];
    char* slash = {"/"}; // Puts a slash after the ./output

    // Character names for file input
    char* red = {"[r].tga"};
    char* blue = {"[b].tga"};
    char* green = {"[g].tga"};

    // Combines the new string of characters together
    strcat(fileOutput, slash);
    strcat(fileOutput, differenceArray);
    strcpy(fileOutput2, fileOutput);
    strcpy(fileOutput3, fileOutput);

    // combines the red character name onto
    // the crafted fileOutput and then sends it to
    // keepredchannel, and prints out the function
    strcat(fileOutput, red);
    RasterImage image = readTGA(argv[1]);
    keepRedChannel(&image);
    writeTGA(fileOutput, &image);

    // combines the blue character name onto
    // the crafted fileOutput and then sends it to
    // keepbluechannel, and prints out the function
    strcat(fileOutput2, blue);
    RasterImage image1 = readTGA(argv[1]);
    keepBlueChannel(&image1);
    writeTGA(fileOutput2, &image1);

    // combines the green character name onto
    // the crafted fileOutput and then sends it to
    // keepgreenchannel, and prints out the function
    strcat(fileOutput3, green);
    RasterImage image2 = readTGA(argv[1]);
    keepGreenChannel(&image2);
    writeTGA(fileOutput3, &image2);
    exit (1);
}





// *****************************************************************
// ********************* rotationFunction **************************
// *****************************************************************

// rotationFunction is called from rotate.c which will
// go through the given file and rotate the image, based
// on what the user has requested (L or R)

void rotationFunction(int argc, char* argv[]){

    // Image rotation request
    char* listedRotations = argv[1];

    // Checks to see if an invalid character was
    // input into the rotation request
    for(int i = 0; i <= listedRotations[i]; i++){
        if(listedRotations[i] == 114 || listedRotations[i] == 108 || listedRotations[i] == 82 || listedRotations[i] == 76){
            continue;
        }
        // Otherwise it prints an error message
        else{
            printf("Invalid rotation string: %s\n", listedRotations);
            exit(1);
        }
    }

    // Loads in image from files
    RasterImage image = readTGA(argv[2]);

    // fileName and fileName array help with
    // the code output
    int fileName = 0;
    int fileNameArray[strlen(argv[2])];

    // This loop checks for l's and r's to 
    // help determine the images rotation
    int letterIterator = 0;
    int total = 0;
    while(letterIterator < strlen(argv[1])){
        if(argv[1][letterIterator] == 'l' || argv[1][letterIterator] == 'L'){
            total += 1;
        }
        if(argv[1][letterIterator] == 'r' || argv[1][letterIterator] == 'R'){
            total -= 1;
        }
        letterIterator += 1;
    }

    // Determines if it's done a full rotation, and will print
    // it's proper rotation, or if it doesn't go through at all
    if(total > 4 || total < -4){
        total = total % 4;
    }

    char shortenedCode[30];
    char* left = "l";
    char* leftLeft = "ll";
    char* right = "r";
    char* rightRight = "rr";

    if(total == 1){
        strcat(shortenedCode, left);
    }
    if(total == 2){
        strcat(shortenedCode, leftLeft);
    }
    if(total == 3){
        strcat(shortenedCode, right);
    }
    if(total == -1){
        strcat(shortenedCode, right);
    }
    if(total == -2){
        strcat(shortenedCode, rightRight);
    }
    if(total == -3){
        strcat(shortenedCode, left);
    }

    // Declares width and height
    int width = image.width;
    int height = image.height;

    // width and height are changable, based on
    // how the image will be fully formatted
    if(total == 1 || total == 3 || total == -1 || total == -3){

        // Captures the width and height
        width = image.height;
        height = image.width;
    }
    // formats and creates the cropped image
    RasterImage rotatedImage = newImage(width, height, RGBA32_RASTER);

    // Sets up raster1 and 2
    int* raster1 = (int*)(image.raster);
    int* raster2 = (int*)(rotatedImage.raster);


    // Finds the name until it reaches the first "/" of the
    // array and writes it backwards, as well as creating a
    // variable which will help the next loop start at the end
    while(argv[2][strlen(argv[2]) - fileName] != 47){
        fileNameArray[fileName] = argv[2][strlen(argv[2]) - fileName];
        fileName += 1;
    }

    // Sets up the array that holds the program name
    int difference = fileName;
    char differenceArray[160];    
    int differenceArrayAddition = 0;

    // This will put the filename onto an array,
    // and stops once a period is hit to avoid
    // printing a .tga
    for(int i = fileName-1; i >= 0; i--){
        if(differenceArrayAddition < difference){
            if(fileNameArray[i] == '.'){
                break;
            }
        }
        if(differenceArrayAddition <= difference){
            differenceArray[differenceArrayAddition] = fileNameArray[i];
            differenceArrayAddition += 1;
        }
    }


    // Sets up the name for rotate image
    char* fileOutput = argv[3];
    char* slash = "/";
    char* crop = {"["};
    char* endChar = {"].tga"};
    strcat(fileOutput, slash);
    strcat(fileOutput, differenceArray);
    strcat(fileOutput, crop);

    // Puts a space if total equated to nothing in the equation
    if(total != 0){
        strcat(fileOutput, shortenedCode);
    }

    // Ends off the file output
    strcat(fileOutput, endChar);

    // This takes care if it's rotated -90 degrees
    // or is rotated 270
    if(total == 1 || total == -3){
        for (unsigned int i= 0; i < image.height; i++){
            for (unsigned int j = 0; j < image.width; j++){
                raster2[(image.width - j - 1) * image.height + i] = raster1[i * image.width + j];
            }
        }
        // writes to TGA, giving the image
        writeTGA(fileOutput, &rotatedImage);
        exit(1);
    }

    // This takes care if it's rotated 90 degrees
    // or is rotated -270
    if(total == -1 || total == 3){
        for (unsigned int i = 0; i < image.height; i++){
            for (unsigned int j = 0; j<image.width; j++){
                raster2[j * image.height + (image.height - 1 - i)] = raster1[i * image.width + j];
            }
        }
        // writes to TGA, giving the image
        writeTGA(fileOutput, &rotatedImage);
        exit(1);
    }

    // This checks if the image is performing a 180 degree rotation
    // essentially it turns upside down
    if(total == 2 || total == -2){
    for (unsigned int i = 0; i < image.height; i++) {
        for (unsigned int j = 0; j < image.width; j++) {
            raster2[(image.height - i - 1) * image.width + j] = raster1[i * image.width + j];
        }
    }
        // writes to TGA, giving the image
        writeTGA(fileOutput, &rotatedImage);
        exit(1);
    }
    else{
        // writes the plain image
        writeTGA(fileOutput, &image);
        exit(1);
    }
}





// *****************************************************************
// ******************* Cropping Functinos **************************
// *****************************************************************


void notNumberforCrop(char* givenNumber){

    // notNumberforCrop is a function specific to 
    // cropImage that determines if the input the
    // user has given are viable integers or not
    int letterCheck = 0;
    while(letterCheck <= strlen(givenNumber)){
        if (((givenNumber[letterCheck] >= 97) && (givenNumber[letterCheck] <= 122)) || givenNumber[letterCheck] == 45 || givenNumber[letterCheck] == 46) {
            // If a non-number character is found, end the program.
            printf("The argument defining the cropping rectangle must be positive integers.\n");
            exit(1);
        }
        letterCheck += 1;
    }
}

// cropImage is called from crop.c which will
// go through the given file and rotate the image, based
// on the user's specifications
void cropImage(int argc, char* argv[]){

    // Captures the row and column coordinates
    // as strings too to see if they're
    // viable options when tested in
    // "notNumberforCrop"
    int Rowvalue = atoi(argv[3]);
    char* RowvalueString = argv[3];
    notNumberforCrop(RowvalueString);
    
    int Colvalue = atoi(argv[4]);
    char* ColvalueString = argv[4];
    notNumberforCrop(ColvalueString);

    // Captures the width and height
    // as strings too to see if they're
    // viable options when tested in
    // "notNumberforCrop"
    int width = atoi(argv[5]);
    char* widthString = argv[5];
    notNumberforCrop(widthString);

    int height = atoi(argv[6]);
    char* heightString = argv[6];
    notNumberforCrop(heightString);

    // Loads in image from files
    RasterImage image = readTGA(argv[1]);
    RasterImage croppedImage = newImage(width, height, RGBA32_RASTER);

    // Checks to see if its even within image bounds
    if(Rowvalue > image.width || Colvalue > image.height){
        printf("The corner of the cropping rectangle lies outside the image\n");
        exit(1);
    }

    //Checks to see if numbers are bigger or smaller
    //than other ones
    if(Rowvalue + width > image.width || Colvalue + height > image.height){
        printf("The cropping rectangle extends outside the image\n");
        exit(1);
    }

    // Declares raster 1 for the original image
    // and raster 2 for the soon to be new cropped image
    int* raster1 = (int*)(image.raster);
    int* raster2 = (int*)(croppedImage.raster);
    unsigned int effectiveWidth  = croppedImage.bytesPerRow / croppedImage.bytesPerPixel;
    for (unsigned int row = 0; row < croppedImage.height; row++){
        for (unsigned int col = 0; col < croppedImage.width; col++){
            raster2[row*effectiveWidth + col] = raster1[(row+Colvalue)*image.width + col + Rowvalue];
        }
    }

    // fileName and fileName array help with
    // the code output
    int fileName = 0;
    int fileNameArray[strlen(argv[1])]; 

    // Finds the name until it reaches the first "/" of the
    // array and writes it backwards, as well as creating a
    // variable which will help the next loop start at the end
    while(argv[1][strlen(argv[1]) - fileName] != 47){
        fileNameArray[fileName] = argv[1][strlen(argv[1]) - fileName];
        fileName += 1;
    }

    // Sets up the array that holds the program name
    int difference = fileName;
    char differenceArray[200];   
    int differenceArrayAddition = 0;

    // This will put the filename onto an array,
    // and stops once a period is hit to avoid
    // printing a .tga
    for(int i = fileName-1; i >= 0; i--){
        if(differenceArrayAddition < difference){
            if(fileNameArray[i] == '.'){
                break;
            }
        }
        if(differenceArrayAddition < difference){
            differenceArray[differenceArrayAddition] = fileNameArray[i];
            differenceArrayAddition += 1;
        }
    }

    // Helps create file name accordingly
    char* fileOutput = argv[2];
    char* slash = "/";
    char* crop = {"[crop].tga"};
    strcat(fileOutput, slash);
    strcat(fileOutput, differenceArray);
    strcat(fileOutput, crop);

    // Prints out file
    writeTGA(fileOutput, &croppedImage);
}