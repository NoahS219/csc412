#!/bin/bash
gcc -Wall -I ImageLibrary/include/ ImageLibrary/src/*.c Applications/dimensions.c -o dimensions
gcc -Wall -I ImageLibrary/include/ ImageLibrary/src/*.c Applications/split.c -o split
gcc -Wall -I ImageLibrary/include/ ImageLibrary/src/*.c Applications/crop.c -o crop
gcc -Wall -I ImageLibrary/include/ ImageLibrary/src/*.c Applications/rotate.c -o rotate