#!/bin/bash
#runs the build script
Scripts/build.sh
imagePath=$1
outputPath=$2

# For loop that goes through file and prints each iteraion
for file in $imagePath/*
do
    ./rotate r $file $outputPath
    ./rotate l $file $outputPath
    ./split $file $outputPath
done