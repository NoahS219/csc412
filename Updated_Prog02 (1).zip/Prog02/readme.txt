Noah Santagata || Prof. Herve || CSC 412 || February 12rd, 2023

**EXTRA CREDIT**
In this assignment, there were extra credit steps that I have
successfully completed, resulting in a more thorough code.

*3.5.3*
My code is able to successfully validate that the rectangle is valid.
By comparing the given user-inputs against the original image, it checks
to see if the user defined cropping image or starting point exit the "grid"

*3.6.2*
My code is able to successfully produce a vastly shortened version of a given
series of r's or l's. It does this by calculating whenever one is placed into
the code (either subtracting or adding one) and produces a proper set of numbers
based on whats given

*5.4*
My implementation of a Doxygen HTML format proved to be effective, as
whenever I desire to upload it to the Doxygen format, it is able to print
a website with my new code implementations

*5.5*
My implementation of a Doxygen/javadoc formatted header file proved to be
effective, as my code follows the proper formatting, and comes out properly
upon visiting the HTML formatted website